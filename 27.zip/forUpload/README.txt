CSE6140 Fall 2020 group project
Algorithm Implementations for solving minimum vertex cover

Teammates:
Ting Liao
Chin Wang
Shen-Yi Cheng

1) Download the file and unzip it

2) cd to the code directory in it

3) python mvc_main.py -inst <graph directory> 
		      -alg [BnB | LS1 | LS2 | Approx]
                      -time <second> 
                      -seed <random seed number>

4) To get the plot for local search result, execute python plot.py